prenom = "Duchelin Fresnel"
nom = "Beaucicot"
heures = int(176)
taux = int(750)

salaire = heures * taux

print(f"Salaire mensuel de {prenom} {nom} : {salaire} gourdes.")