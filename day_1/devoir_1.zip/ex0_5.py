forfait = int(input("Saisissez le forfait mensuel : "))
supplement = int(input("Saisissez le supplement : "))

total = forfait + supplement

print("==================================================")
print(f"Le montant a payer est : {total} gourdes")