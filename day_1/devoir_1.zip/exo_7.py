prenom = "Floria"
Nom = "Carpon"
AGE = "19"
ville = "Port au Prince"
formation = "code de la route"
mois_inscription = int(4)
mois_reussite = int(6)
nb_mois = mois_reussite - mois_inscription
print(f"Lélève {prenom} {Nom}, âgé de {AGE} ans a suivi la formation {formation} à, {ville} pendant {nb_mois} mois")