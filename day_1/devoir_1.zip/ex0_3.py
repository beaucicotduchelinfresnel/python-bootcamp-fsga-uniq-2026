x = int(input("Saisissez la valeur de x : "))

#calcul
fonction = 4 * x +3

print(f"Pour x = {x}, f({x}) = f({fonction})")