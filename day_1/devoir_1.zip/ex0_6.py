nbre_recharge = int(input("Saisissez le nombre de recharges : "))
val_recharge = int(input("Saisissez la valeur de chaque recharge : "))
#calcul
credit = nbre_recharge * val_recharge
print("==================================================")
print(f"Le montant total de credit est : {credit} gourdes")